# Assets - OwlStrikeTrading
Includes:
- owlstrike_logo.svg (vector logo: Knight with owl on shield - placeholder)
- favicon.ico (placeholder)
- Additional styling assets should be added here.
