# Frontend - OwlStrikeTrading
React + TypeScript UI skeleton with green/black 1980s theme.
Files:
- src/App.tsx
- package.json
- public/index.html
- README.md
