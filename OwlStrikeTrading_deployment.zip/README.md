# Deployment - OwlStrikeTrading
This folder contains Dockerfiles and docker-compose.yml for deploying backend and frontend.
Replace placeholders with real files before building.
