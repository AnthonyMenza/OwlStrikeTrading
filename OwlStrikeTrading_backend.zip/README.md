# Backend - OwlStrikeTrading
Contains FastAPI backend with trading logic, moving averages, order flow analysis, and alerts.
Files:
- main.py (FastAPI app skeleton)
- requirements.txt (Python deps)
- README.md (this file)

NOTE: Robinhood integration requires `robin_stocks`. Keep credentials out of repo.
